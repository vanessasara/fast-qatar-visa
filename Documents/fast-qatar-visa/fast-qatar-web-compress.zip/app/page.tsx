import Hero from "@/components/sections/Hero";
import ServicesPreview from "@/components/sections/ServicesPreview";
import HowItWorks from "@/components/sections/HowItWorks";
import WorkVisaCategories from "@/components/sections/WorkVisaCategories";
import Statistics from "@/components/sections/Statistics";
import WhyChooseUs from "@/components/sections/WhyChooseUs";
import Testimonials from "@/components/sections/Testimonials";
import CTASection from "@/components/sections/CTASection";

export default function Home() {
  return (
    <>
      <Hero />
      <ServicesPreview />
      <HowItWorks />
      <WorkVisaCategories />
      <Statistics />
      <WhyChooseUs />
      <Testimonials />
      <CTASection />
    </>
  );
}
